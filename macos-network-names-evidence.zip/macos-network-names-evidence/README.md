# macOS network names and addresses

Base: ecoAPM/WiFiSurveyor at `9ce68bb4832f40074ab8c72a94dd89a36e1bb7a1`. The patch applies directly to this base.

## Captures

- `system-profiler.connected.sanitized.json`: actual output of `/usr/sbin/system_profiler SPAirPortDataType -detailLevel full -json`. With Wi-Fi connected, all 19 neighboring network names were `<redacted>`.
- `corewlan.with-permission.connected.sanitized.json`: actual packaged scanner output after Location Services permission was granted, launched through LaunchServices. It returned 27 access points, 24 visible names and all 27 BSSIDs, with no error or stderr. Three SSIDs are empty; the capture does not establish why.
- `verification.json`: test counts, build checks, browser observations and the separate scan without Wi-Fi association.
- `api-status.json` and `environment.txt`: public API status and OS/tool versions.

Visible SSIDs and MAC addresses were replaced with consistent pseudonyms. The mapping is not included. JSON structure, RSSI, channels, bands, counts, empty strings and `<redacted>` were preserved. These are separate connected scans; counts may fluctuate. The disconnected acceptance results are recorded separately, not presented as disconnected raw dumps.

## Reproduce

On macOS with Xcode Command Line Tools installed, apply this patch to the base and publish for the machine's architecture:

```sh
dotnet publish Mac/Mac.csproj -c Release -r osx-arm64 -o publish/osx-arm64
```

For Intel, use `osx-x64` instead. Keep `WiFiSurveyor.Scanner.app` beside the executable. Run the service and allow **WiFiSurveyor Scanner** in the macOS Location Services prompt. The Access Point list should show network names.

To inspect the scanner independently, from the published directory:

```sh
open -n -W -g --stdout "$PWD/scanner-output.json" --stderr "$PWD/scanner-errors.txt" "$PWD/WiFiSurveyor.Scanner.app"
cat scanner-output.json
```

Permission is managed under System Settings > Privacy & Security > Location Services. If denied, the scanner should explain which setting to change. Denial/revocation/global-disable/timeout paths were inspected in source, but not exercised on this machine.

Run the existing tests from the repository root:

```sh
dotnet test -p:RuntimeIdentifier= -p:PublishSingleFile=false
```

CoreWLAN is Apple's public Wi-Fi API; the methods used are not deprecated in the checked macOS 27 SDK. `system_profiler` is removed from the service's scanning path and retained here only for comparison. The app bundle and permission prompt follow the macOS privacy requirement for SSID/BSSID. See [CoreWLAN](https://developer.apple.com/documentation/corewlan) and [Apple's explanation of Location privilege](https://developer.apple.com/forums/thread/759044).

No coordinates are used, stored or sent by the scanner. The test bundle is ad hoc signed. A rebuild may require permission again. Intel runtime, downloaded-package Gatekeeper, Developer ID signing/notarization and upstream workflows remain unverified. Future macOS privacy changes cannot be guaranteed against.
