# Scanning without Wi-Fi association

Base: ecoAPM/WiFiSurveyor at `9ce68bb4832f40074ab8c72a94dd89a36e1bb7a1`. The patch applies directly to this base.

## Captures

- `system-profiler.connected.sanitized.json` is actual output of `/usr/sbin/system_profiler SPAirPortDataType -detailLevel full -json`, taken with Wi-Fi connected. The `awdl0` entry has no `spairport_airport_other_local_wireless_networks` property. This is not a disconnected capture.
- `corewlan.without-permission.connected.sanitized.json` is actual scanner output with Wi-Fi connected: 27 access points. Names and addresses are redacted because this scanner does not have Location Services permission.
- `missing-neighbors.synthetic.json` is a deliberately reduced fixture, NOT a macOS dump. It demonstrates the missing property which makes the original parser's `GetProperty("spairport_airport_other_local_wireless_networks")` call throw at `Mac/MacSignalParser.cs:15` in the base commit.
- `verification.json` records the separate live check without Wi-Fi association: radio on, 32 access points returned by the scanner. No disconnected profiler dump was retained.
- `api-status.json` records the public Apple API and SDK status check; `environment.txt` records tool versions.

MAC addresses were replaced with consistent local pseudonyms. JSON structure, channels, RSSI, counts, empty strings and `<redacted>` were preserved. Captures were taken separately; counts may fluctuate.

## Reproduce

On macOS with Xcode Command Line Tools installed, apply this patch to the base and publish for the machine's architecture:

```sh
dotnet publish Mac/Mac.csproj -c Release -r osx-arm64 -o publish/osx-arm64
```

For Intel, use `osx-x64` instead. Leave `WiFiSurveyor.Scanner` beside `WiFiSurveyor`.

Enable the Wi-Fi radio, disconnect from the current network, then run the service. The scan should return nearby access points without requiring a Wi-Fi connection. You can inspect the scanner directly from the published directory:

```sh
./WiFiSurveyor.Scanner > scanner-output.json
```

This change does not request location permission. macOS may still redact SSID and BSSID, as the connected capture shows.

Run the existing tests from the repository root:

```sh
dotnet test -p:RuntimeIdentifier= -p:PublishSingleFile=false
```

CoreWLAN is Apple's public API for querying Wi-Fi interfaces and scanning networks. The methods used are not deprecated in the checked macOS 27 SDK. `system_profiler` is removed from the service's scanning path; it is included here only for diagnosis. See [CoreWLAN](https://developer.apple.com/documentation/corewlan) and [scanForNetworks(withSSID:)](https://developer.apple.com/documentation/corewlan/cwinterface/scanfornetworks(withssid:)). Future macOS changes cannot be guaranteed against. Intel runtime, downloaded-package Gatekeeper and the upstream workflows were not exercised.
