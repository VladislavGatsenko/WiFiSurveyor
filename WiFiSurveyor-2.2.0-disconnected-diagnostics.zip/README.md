# WiFiSurveyor 2.2.0: Wi-Fi enabled, no AP association

Captured on macOS 27.0.1 / Apple Silicon using the official, unmodified arm64 release. The release archive SHA-256 matches the digest published by GitHub. See environment.txt for commands, timestamps and hashes.

## Files

- WiFiSurveyor-2.2.0-disconnected-information.log: application output at the default Information level; the dictionary error appears twice.
- WiFiSurveyor-2.2.0-disconnected-debug.log: application output at Debug level, including KeyNotFoundException and the MacSignalParser.Parse stack trace.
- system-profiler-disconnected-before.json and system-profiler-disconnected-after.json: complete JSON output captured before and after the application runs.
- environment.txt: release provenance and verified Wi-Fi state.

Both profiler captures identify en1 as spairport_status_disassociated. They contain 21 and 24 nearby networks, respectively, in spairport_airport_local_wireless_networks, and have no spairport_airport_other_local_wireless_networks or spairport_current_network_information property. The v2.2.0 parser reads spairport_airport_other_local_wireless_networks with GetProperty, producing the recorded exception.

The Wi-Fi radio was already on and disconnected. No Wi-Fi settings were changed; Ethernet remained the default route. No sudo was used. The application binary and appsettings.json were not edited; logging was selected through an environment variable. The dev argument is used to suppress browser launch; the Wi-Fi scanning code is unchanged.

MAC addresses are replaced with consistent local pseudonyms, and any visible SSIDs are anonymized. JSON keys, array sizes, status, channels, signal values, blank strings and literal <redacted> values are retained. Local user paths are replaced in logs; stack traces and error messages are preserved. These are real captures, not synthetic fixtures.

